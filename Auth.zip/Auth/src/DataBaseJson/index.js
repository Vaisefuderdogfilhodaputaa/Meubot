const {
    JsonDatabase,
  } = require("wio.db");
  
  const config = new JsonDatabase({
    databasePath: "./src/DataBaseJson/config.json"
  });
  
  const users = new JsonDatabase({
    databasePath: "./src/DataBaseJson/users.json"
  });

  const message = new JsonDatabase({
    databasePath: "./src/DataBaseJson/message.json"
  });

  const carrinhos = new JsonDatabase({
    databasePath: "./src/DataBaseJson/carrinho.json"
  });
  
  
  module.exports = {
    config,
    users,
    carrinhos,
    message
  }