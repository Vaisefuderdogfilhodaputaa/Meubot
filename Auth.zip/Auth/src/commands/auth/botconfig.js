const { ApplicationCommandType, EmbedBuilder, ButtonBuilder, ActionRowBuilder } = require("discord.js");
const { owner } = require("../../../token.json");
const { users, config } = require("../../DataBaseJson/index")
const { painel } = require("../../functions/painel.js")
const axios = require("axios");
const discordOauth = require("discord-oauth2");
const oauth = new discordOauth();


module.exports = {
    name: "botconfig",
    description: "[👷] Comece a configurar o seu sistema de oauth2!",
    type: ApplicationCommandType.ChatInput,
    run: async(client, interaction) => { 

        if(interaction.user.id !== owner) return interaction.reply({content:`\`❌\` | Permissão não encontrada.`, ephemeral:true});
        const all = await users.all().filter(a => a.data.username);

        painel(interaction, client)
    }
}