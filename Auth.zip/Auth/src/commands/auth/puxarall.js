const { ApplicationCommandType, EmbedBuilder, ApplicationCommandOptionType } = require("discord.js");
const {url, clientid, secret, role} = require("../../DataBaseJson/config.json");
const { owner } = require("../../../token.json");
const { config } = require("../../../src/DataBaseJson")
const { JsonDatabase } = require("wio.db");
const users = new JsonDatabase({databasePath:"./src/DataBaseJson/users.json"});
const axios = require("axios");
const discordOauth = require("discord-oauth2");
const oauth = new discordOauth();
const FormData = require('form-data');



module.exports = {
    name:"pull",
    description:"[📁] Puxar todos os usuarios vinculado.",
    type: ApplicationCommandType.ChatInput,
    options:[
        {
            name:"servidor",
            description:"Insira o id de um servidor",
            type: ApplicationCommandOptionType.String,
            required: false
        }
    ],
    run: async(client, interaction) => {
        if(interaction.user.id !== owner) return interaction.reply({content: `\`❌\` | Permissão não encontrada.`, ephemeral:true});
        const all = await users.all().filter(a => a.data.username);
        const guild_id = interaction.options.getString("servidor") || interaction.guild.id;
        const guild = interaction.client.guilds.cache.get(guild_id);
        if(!guild) return interaction.reply({content:`Servidor não Encontrado.`, ephemeral:true});

        let yes = 0;
        let no = 0;
        
        await interaction.reply({
            embeds: [
                new EmbedBuilder()
                .setTitle(`**Oauth2**`)
                .setDescription("-# \`💻\` Processo de **return** esta iniciando")
                .setAuthor({ name: "Iniciando Processo", iconURL: "https://cdn.discordapp.com/emojis/1299377603232268288.png?size=2048" })
                .addFields(
                    {
                        name:"📋 Verificados",
                        value:` **\`📁 (x${all.length}) Usuarios\`**`
                    },
                    {
                        name:"✅ Puxados",
                        value:`**\`🟢 (x${yes}) Puxados\`**`,
                    },
                    {
                        name:"❌ Não puxados",
                        value:`**\`🔴 (x${no}) Usuarios Não puxados\`**`,
                    },
                )
            ]
        });
        for(const user of all) {
            const userToken = await renovartoken(user.ID, user.data.refreshToken ,user.data.code);
            await oauth.addMember({
                accessToken: userToken?.access_token ?? user.data.acessToken,
                botToken: client.token,
                guildId: guild.id,
                userId: user.ID,
                nickname: user.data.username,
                roles: [ ],
                mute: false,
                deaf: false,
            }).then(() => {
                yes++;
            }).catch((err) => { 
                no++
            });
            await users.set(`${user.ID}.acessToken`,userToken?.access_token ?? user.data.acessToken);
            await users.set(`${user.ID}.refreshToken`,userToken?.refresh_token ?? user.data.refreshToken);
            interaction.editReply({
                embeds: [
                    new EmbedBuilder()
                    .setTitle(`**Oauth2**`)
                    .setDescription("-# \`💻\` Processo de **return** iniciado com sucesso")
                    .setAuthor({ name: "Processo Iniciado", iconURL: "https://cdn.discordapp.com/emojis/1246953310930473071.png?size=2048" })
                    .addFields(
                        {
                            name:"📋 Verificados",
                            value:` **\`📁 (x${all.length}) Usuarios\`**`
                        },
                        {
                            name:"✅ Puxados",
                            value:`**\`🟢 (x${yes}) Puxados\`**`,
                        },
                        {
                            name:"❌ Não puxados",
                            value:`**\`🔴 (x${no}) Usuarios Não puxados\`**`,
                        },
                    )
                ]
            });
        }
            interaction.editReply({
                embeds: [
                    new EmbedBuilder()
                    .setDescription(`# Oauth2\n\n-# \`🛠\` **Processo de return finalizado com sucesso**\n-# **Total de **\`x${yes}\`** Puxados**`)
                    .setAuthor({ name: "Processo Finalizado", iconURL: "https://cdn.discordapp.com/emojis/1246953215380160593.png?size=2048" })
                    .addFields(
                        {
                            name:"📋 Verificados",
                            value:` **\`📁 (x${all.length}) Usuarios\`**`
                        },
                        {
                            name:"✅ Puxados",
                            value:`**\`🟢 (x${yes}) Puxados\`**`,
                        },
                        {
                            name:"❌ Não puxados",
                            value:`**\`🔴 (x${no}) Usuarios Não puxados\`**`,
                        },
                    )
                    .setFooter({ text: "Nyx Community", iconURL: "https://cdn.discordapp.com/emojis/1246952319241683055.png?size=2048" })
                ]
            });
        interaction.followUp({
            content:`\`🟢 Processo finalizado com sucesso\``,
            ephemeral: true
        });
    }
}

async function renovartoken(userId, refreshToken, code) {
    try {
		const response = await axios.post(
    'https://discord.com/api/oauth2/token',
    `client_id=${config.get("clientid")}&code=${code}&client_secret=${config.get("secret")}&refresh_token=${refreshToken}&grant_type=refresh_token&redirect_uri=${config.get("url")}/oauth2/return&scope=identify`,
    {
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
    }
);
        if (response.data && response.data.access_token) {
            const renewedToken = response.data.access_token;
            const newRefreshToken = response.data.refresh_token;

            return { access_token: renewedToken, refresh_token: newRefreshToken };
        } else {
            return { access_token: null, refresh_token: null };
        }
    } catch (error) {
        return { access_token: null, refresh_token: null };
    }
}
