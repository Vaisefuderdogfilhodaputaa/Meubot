const { ApplicationCommandType, EmbedBuilder, ButtonBuilder, ActionRowBuilder } = require("discord.js");
const { owner } = require("../../../token.json");
const { users, config } = require("../../DataBaseJson/index");
const { painel } = require("../../functions/painel.js");
const axios = require("axios");
const discordOauth = require("discord-oauth2");
const oauth = new discordOauth();

module.exports = {
    name: "sell",
    description: "[💲] Começar a vender membros!",
    type: ApplicationCommandType.ChatInput,
    run: async(client, interaction) => { 

        if (interaction.user.id !== owner) {
            return interaction.reply({ content: "`❌` | Permissão não encontrada.", ephemeral: true });
        }

        const pix = config.get("revenda.pix");
        const logs = config.get("revenda.logs");
        const role = config.get("revenda.role");
        const valor = config.get("revenda.valor");

        if (!pix || !logs ||!valor || !role) {
            return interaction.reply({ content: "`❌` |  Configure o sistema antes de vender.", ephemeral: true });
        }

        const all = await users.all().filter(a => a.data.username);

        const embed = new EmbedBuilder()
            .setAuthor({ name: "Compra de M3mbr0s", iconURL: client.user.displayAvatarURL({ dynamic: true }) })
            .setDescription(`- M3mbr0s Reais\n- 100% Brasileiros\n- Qualidade Premium\n- Melhor preço do mercado\n- Entrega rápida`)
            .setImage("https://i.ibb.co/kKj5PNv/Barrinha-1-returnrevendedores.webp")
            .setFooter({ text: `x${all.length} Membros Disponiveis`, iconURL: interaction.guild.iconURL() });

        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId("buymembers").setLabel("Comprar").setEmoji("1246953283826745476").setStyle(3)
        );

        await interaction.channel.send({ embeds: [embed], components: [row] });
        await interaction.reply({ content: "`✅` Mensagem de vendas enviado com sucesso.", ephemeral: true });
    }
};
