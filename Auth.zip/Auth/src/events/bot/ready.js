const {} = require("discord.js");


module.exports = {
    name:"ready",
    run:async(client) => {console.clear();
        console.log("\n");
        console.log('\x1b[37m%s\x1b[0m',"                      ███╗   ██╗██╗   ██╗██╗  ██╗    ██████╗     ██████╗                 ")
        console.log('\x1b[37m%s\x1b[0m',"                      ████╗  ██║╚██╗ ██╔╝╚██╗██╔╝    ╚════██╗   ██╔═████╗                ")
        console.log('\x1b[37m%s\x1b[0m',"                      ██╔██╗ ██║ ╚████╔╝  ╚███╔╝      █████╔╝   ██║██╔██║                ")
        console.log('\x1b[37m%s\x1b[0m',"                      ██║╚██╗██║  ╚██╔╝   ██╔██╗      ╚═══██╗   ████╔╝██║                ")
        console.log('\x1b[37m%s\x1b[0m',"                      ██║ ╚████║   ██║   ██╔╝ ██╗    ██████╔╝██╗╚██████╔╝                ")
        console.log('\x1b[37m%s\x1b[0m',"                      ╚═╝  ╚═══╝   ╚═╝   ╚═╝  ╚═╝    ╚═════╝ ╚═╝ ╚═════╝                 ")
        console.log('\x1b[37m%s\x1b[0m',"                                                                    ")
        console.log('\x1b[37m%s\x1b[0m',"                                                                                        ")
        console.log('\x1b[37m%s\x1b[0m', '                             > Desenvolvido por @reidelas24444 <');
        console.log('\x1b[37m%s\x1b[0m', '                              > Creditos dos emojis e sistema de pagamento @gostbanido <');
        console.log('\x1b[37m%s\x1b[0m', '                               > Creditos aos owners + gostosos da nyx <');
        console.log('\x1b[37m%s\x1b[0m', `                               > Estou online em ${client.user.username} <`);
        console.log('\x1b[37m%s\x1b[0m', `                                > Estou em ${client.guilds.cache.size}, Servidores <`);
        console.log('\x1b[37m%s\x1b[0m', `                                 > discord.gg/nyxc <`);
        console.log('\x1b[37m%s\x1b[0m', `                                  > Oauth2 V3 <`);
        

    }
}