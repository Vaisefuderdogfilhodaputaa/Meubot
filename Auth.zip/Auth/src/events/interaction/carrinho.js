const { ApplicationCommandType, EmbedBuilder, ModalBuilder, TextInputBuilder, ActionRowBuilder, TextInputStyle, ChannelSelectMenuBuilder, ChannelType, ButtonBuilder, RoleSelectMenuBuilder, UserSelectMenuBuilder, AttachmentBuilder, StringSelectMenuBuilder, ThreadAutoArchiveDuration } = require("discord.js");
const { config, message, carrinhos, users } = require("../../DataBaseJson");
const discordOauth = require("discord-oauth2");
const oauth = new discordOauth();
const { owner } = require("../../../token.json")

module.exports = {
    name: "interactionCreate",
    run: async (interaction, client) => {
        const { customId } = interaction;
        if (!customId) return;

        if (customId === "buymembers") {

            const blacklist = config.get("blacklist.users") || []

            if (blacklist.includes(interaction.user.id)) {
                return await interaction.reply({
                    content: "**\`❌ Você esta na blacklist.\`**",
                    ephemeral: true
                });
            }


            const revenda2024 = config.get("revenda.status");
            if (revenda2024 === false) {
                return await interaction.reply({
                    content: "**\`❌ O sistema de venda de membros está desabilitado.\`**",
                    ephemeral: true
                });
            }

            const quantidademembros2024 = await users.all().filter(a => a.data.username).length;
            if (quantidademembros2024 < 1) {
                return await interaction.reply({
                    content: "**\`❌ Necessario ter pelo menos 1 membro verificado para comprar.\`**",
                    ephemeral: true
                });
            }

            const verify2024 = interaction.channel.threads.cache.find(thread => thread.name === `🎫・${interaction.user.username}・${interaction.user.id}`);
            if (verify2024) {
                const row = new ActionRowBuilder().addComponents(
                    new ButtonBuilder().setURL(`https://discord.com/channels/${interaction.guild.id}/${verify2024.id}`).setLabel("Visualizar").setEmoji("1246953471111069786").setStyle(5)
                );

                return await interaction.reply({
                    content: "**\`❌ Você já tem um carrinho aberto. Você pode visualizar o carrinho existente utilizando o botão abaixo.\`**",
                    components: [row],
                    ephemeral: true
                });
            }

            await interaction.reply({ content: "\`⚪ Carrinho está sendo criado.\`", ephemeral: true });
            const canal = await interaction.channel.threads.create({
                name: `🎫・${interaction.user.username}・${interaction.user.id}`,
                type: ChannelType.PrivateThread,
                autoArchiveDuration: ThreadAutoArchiveDuration.OneDay,
                reason: `Ticket criado por ${interaction.user.username}`,
                invitable: false,
            });

            const row = new ActionRowBuilder().addComponents(
                new ButtonBuilder().setURL(`https://discord.com/channels/${interaction.guild.id}/${canal.id}`).setLabel("Visualizar").setEmoji("1246953471111069786").setStyle(5)
            );

            await interaction.editReply({ content: "**\`✅ Seu Carrinho foi criado com sucesso.\`**", components: [row], ephemeral: true });
            carrinhos.set(`${canal.id}.canal`, canal.id);
            carrinhos.set(`${canal.id}.quantidade`, "1");
            carrinhos.set(`${canal.id}.dono`, interaction.user.id);
            carrinhos.set(`${canal.id}.valor`, config.get("revenda.valor"));

            const quantidade = carrinhos.get(`${canal.id}.quantidade`) || "1";
            const valorBase = config.get("revenda.valor") || "0.40"
            const valorTotal = (valorBase * quantidade).toFixed(2);

            const row24 = new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId("remmais").setEmoji("1246953362037932043").setStyle(4),
                new ButtonBuilder().setCustomId("editquantidade").setEmoji("1246953149009367173").setStyle(2),
                new ButtonBuilder().setCustomId("addmais").setEmoji("1246953350067388487").setStyle(1),
                new ButtonBuilder().setCustomId("cancelarcarrinho").setEmoji("1246953338541441036").setStyle(4),
                new ButtonBuilder().setCustomId("continuarbuy").setEmoji("1246955020050759740").setStyle(3)
            )
            

            await canal.send({ content: `## Compra de Membros\n- Olá, ${interaction.user} todos membros são 100% reais, utilize os botões abaixo para selecionar a quantidade que deseja comprar.\n\n\`👤\`・Quantidade: ${carrinhos.get(`${canal.id}.quantidade`) || "**\`🔴 Not Found\`**"} Membro(s)\n\`💵\`・Valor: R$ ${valorTotal}\n\n-# \`⚠️\`・Você pode comprar entre 1 á ${quantidademembros2024} membros.`, components: [row24] })

            const canal2024443 = await canal.send({ content: `${interaction.user} - <@&${config.get("revenda.role") || ""}> - <@${owner || ""}>` });
            await canal2024443.delete();
        }

        if (customId === "editquantidade") {
            const totalMembros = await users.all().filter(a => a.data.username).length;
            const modal = new ModalBuilder()
                .setCustomId('quantidade_modal')
                .setTitle('Editar Quantidade')
                .addComponents(
                    new ActionRowBuilder().addComponents(
                        new TextInputBuilder()
                            .setCustomId('quantidade_input')
                            .setLabel('Digite a quantidade de membros')
                            .setStyle(TextInputStyle.Short)
                            .setPlaceholder(`Maximo: ${totalMembros}`)
                            .setRequired(true)
                            .setMaxLength(3) 
                    )
                );
        
            await interaction.showModal(modal);
        }
        
        if (interaction.customId === 'quantidade_modal') {
            const quantidadeInput = interaction.fields.getTextInputValue('quantidade_input');
            const totalMembros = await users.all().filter(a => a.data.username).length;
            let quantidade = carrinhos.get(`${interaction.channel.id}.quantidade`) || 10;
        
            const quantidadeNumerica = parseInt(quantidadeInput);
        
            if (isNaN(quantidadeNumerica)) {
                return await interaction.reply({
                    content: '\`⚠️\` Você deve inserir um número válido.',
                    ephemeral: true
                });
            }


    if (quantidadeNumerica < 1) {
        return await interaction.reply({
            content: '\`⚠️\` A quantidade mínima é de 1 membro.',
            ephemeral: true
        });
    }
        
            if (quantidadeNumerica > totalMembros) {
                return await interaction.reply({
                    content: `\`⚠️\` Você so pode comprar \`x${totalMembros}\` Membros.`,
                    ephemeral: true
                });
            }
        
            carrinhos.set(`${interaction.channel.id}.quantidade`, quantidadeNumerica);
        
            const valorBase = config.get("revenda.valor") || 0.40;
            const valorTotal = (valorBase * quantidadeNumerica).toFixed(2);
        
            const row24 = new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId("remmais").setEmoji("1246953362037932043").setStyle(4),
                new ButtonBuilder().setCustomId("editquantidade").setEmoji("1246953149009367173").setStyle(2),
                new ButtonBuilder().setCustomId("addmais").setEmoji("1246953350067388487").setStyle(1),
                new ButtonBuilder().setCustomId("cancelarcarrinho").setEmoji("1246953338541441036").setStyle(4),
                new ButtonBuilder().setCustomId("continuarbuy").setEmoji("1246955020050759740").setStyle(3)
            );

            carrinhos.set(`${interaction.channel.id}.valor`, valorTotal)
        
            await interaction.update({
                content: `## Compra de Membros\n- Olá, ${interaction.user} todos membros são 100% reais, utilize os botões abaixo para selecionar a quantidade que deseja comprar.\n\n\`👤\`・Quantidade: ${quantidadeNumerica} Membro(s)\n\`💵\`・Valor: R$ ${valorTotal}\n\n-# \`⚠️\`・Você pode comprar entre 1 á ${totalMembros} membros.`,
                components: [row24]
            });
        }
        
        if (customId === "addmais") {
            const totalMembros = await users.all().filter(a => a.data.username).length;
            const quantidade = carrinhos.get(`${interaction.channel.id}.quantidade`) || 10;
        
            if (quantidade >= Number(totalMembros)) {
                return await interaction.reply({ content: `\`🔴\` A quantidade não pode passar de \`x${Number(totalMembros)}\``, ephemeral: true });
            };
        
            if (quantidade < Number(totalMembros)) {
                await carrinhos.add(`${interaction.channel.id}.quantidade`, 1);
            };

            const valorBase = await config.get("revenda.valor") || 0.40;
            const valorTotal = parseFloat(valorBase * quantidade).toFixed(2);
            carrinhos.set(`${interaction.channel.id}.valor`, valorTotal)
        
            await interaction.update({
                content: `## Compra de Membros\n- Olá, ${interaction.user} todos membros são 100% reais, utilize os botões abaixo para selecionar a quantidade que deseja comprar.\n\n\`👤\`・Quantidade: ${quantidade} Membro(s)\n\`💵\`・Valor: R$ ${valorTotal}\n\n-# \`⚠️\`・Você pode comprar entre 1 á ${totalMembros} membros.`,
                components: [
                    new ActionRowBuilder().addComponents(
                        new ButtonBuilder().setCustomId("remmais").setEmoji("1246953362037932043").setStyle(4),
                        new ButtonBuilder().setCustomId("editquantidade").setEmoji("1246953149009367173").setStyle(2),
                        new ButtonBuilder().setCustomId("addmais").setEmoji("1246953350067388487").setStyle(1),
                        new ButtonBuilder().setCustomId("cancelarcarrinho").setEmoji("1246953338541441036").setStyle(4),
                        new ButtonBuilder().setCustomId("continuarbuy").setEmoji("1246955020050759740").setStyle(3)
                    )
                ]
            });
        }
        

        if (customId === "remmais") {
            const totalMembros = await users.all().filter(a => a.data.username).length;
            let quantidade = carrinhos.get(`${interaction.channel.id}.quantidade`) || 10;
            
            if (quantidade <= 1) {
                return await interaction.update({
                    content: `## Compra de Membros\n- Olá, ${interaction.user} todos membros são 100% reais, utilize os botões abaixo para selecionar a quantidade que deseja comprar.\n\n\`👤\`・Quantidade: ${quantidade} Membro(s)\n\`💵\`・Valor: R$ ${(config.get("revenda.valor") * quantidade).toFixed(2)}\n\n-# \`⚠️\`・A quantidade mínima para retirada é 10 membros.`,
                    components: [
                        new ActionRowBuilder().addComponents(
                            new ButtonBuilder().setCustomId("remmais").setEmoji("1246953362037932043").setStyle(4),
                            new ButtonBuilder().setCustomId("editquantidade").setEmoji("1246953149009367173").setStyle(2),
                            new ButtonBuilder().setCustomId("addmais").setEmoji("1246953350067388487").setStyle(1),
                            new ButtonBuilder().setCustomId("cancelarcarrinho").setEmoji("1246953338541441036").setStyle(4),
                            new ButtonBuilder().setCustomId("continuarbuy").setEmoji("1246955020050759740").setStyle(3)
                        )
                    ]
                });
            }
        
            quantidade -= 1;
            carrinhos.set(`${interaction.channel.id}.quantidade`, quantidade);
        
            const valorBase = config.get("revenda.valor") || 0.40;
            const valorTotal = (valorBase * quantidade).toFixed(2);
            carrinhos.set(`${interaction.channel.id}.valor`, valorTotal)
        
            await interaction.update({
                content: `## Compra de Membros\n- Olá, ${interaction.user} todos membros são 100% reais, utilize os botões abaixo para selecionar a quantidade que deseja comprar.\n\n\`👤\`・Quantidade: ${quantidade} Membro(s)\n\`💵\`・Valor: R$ ${valorTotal}\n\n-# \`⚠️\`・Você pode comprar entre 1 á ${totalMembros} membros.`,
                components: [
                    new ActionRowBuilder().addComponents(
                        new ButtonBuilder().setCustomId("remmais").setEmoji("1246953362037932043").setStyle(4),
                        new ButtonBuilder().setCustomId("editquantidade").setEmoji("1246953149009367173").setStyle(2),
                        new ButtonBuilder().setCustomId("addmais").setEmoji("1246953350067388487").setStyle(1),
                        new ButtonBuilder().setCustomId("cancelarcarrinho").setEmoji("1246953338541441036").setStyle(4),
                        new ButtonBuilder().setCustomId("continuarbuy").setEmoji("1246955020050759740").setStyle(3)
                    )
                ]
            });
        }
        
        

        if (customId === "cancelarcarrinho") {
           const cancel = new EmbedBuilder()
           .setDescription(`## Cancelamento\n\`🔴 O usuario\` ${interaction.user} \`finalizou um carrinho\`\n-# **\`🛠\` Informações Abaixo**\n\n-# Id do carrinho: <#${interaction.channel.id}>(\`${interaction.channel.id}\`)\n-# Dono do carrinho: <@${carrinhos.get(`${interaction.channel.id}.dono`)}>(**\`${carrinhos.get(`${interaction.channel.id}.dono`)}\`**)`)
           .setColor("NotQuiteBlack")

           await carrinhos.delete(interaction.channel.id)
           await interaction.channel.delete()
           const channel = interaction.guild.channels.cache.get(config.get("revenda.logs"));
           if (channel) {
            channel.send({ embeds: [cancel] })
           }
        }

        if (customId === "continuarbuy") {
            const quantidade = carrinhos.get(`${interaction.channel.id}.quantidade`);
            const valorBase = config.get("revenda.valor") || 0.40;
            const valorTotal = (valorBase * quantidade).toFixed(2);

            carrinhos.set(`${interaction.channel.id}.valor`, valorTotal);
            const valor = carrinhos.get(`${interaction.channel.id}.valor`) || valorTotal
            pagamento(valor)
         }

         if (customId === "copyChave") {
            const tipo = await config.get("revenda.tipo") || "";
            const chave = await config.get("revenda.pix") || "";

            await interaction.reply({ content: `${chave}`, ephemeral: true })
         }

         if (customId === "aproveSemiAuto") {

            if (!config.get("revenda.role")) {
                return interaction.reply({ content: `\`🔎\` Cargo de aprovador não setado!`, ephemeral: true });
            };

            if (!interaction.member.roles.cache.has(config.get("revenda.role"))) {
                return interaction.reply({ content: `\`❌\` Você não tem permissão para fazer isso!`, ephemeral: true });
            };

            const currentStatus = await carrinhos.get(`${interaction.channel.id}.status`);
            if (currentStatus === "aprovado") {
                return interaction.reply({ content: `\`⚠️\` O pagamento já foi aprovado.`, ephemeral: true });
            };

            await carrinhos.set(`${interaction.channel.id}.status`, "aprovado");
            await carrinhos.set(`${interaction.channel.id}.aprovadopor`, interaction.user.id);
            interaction.reply({ content: `\`✅\` Pagamento aprovado com êxito.`, ephemeral: true });
            
        };

        if (customId === "sendmembers") {
        const request = carrinhos.get(`${interaction.channel.id}.statusenviado`) || false

        if (request === true ) {
            return interaction.reply({ content: "\`🟢 Você ja enviou os membros, abra um carrinho novamente.\`", ephemeral: true })
        }

        const modal = new ModalBuilder()
            .setCustomId('sendmembers_modal')
            .setTitle('Puxar Membros');
    
        const urlinput2024 = new TextInputBuilder()
            .setCustomId('idserverinput')
            .setLabel('Server Id')
            .setPlaceholder("Insira o id do server")
            .setStyle(TextInputStyle.Short)
            .setMaxLength(400)
            .setRequired(true);
    
        const row24 = new ActionRowBuilder().addComponents(urlinput2024);
        modal.addComponents(row24);
    
        await interaction.showModal(modal); 
        };

        if (interaction.isModalSubmit()) {
            if (interaction.customId === "sendmembers_modal") {
                const idserver = interaction.fields.getTextInputValue("idserverinput");
                const quantidade = carrinhos.get(`${interaction.channel.id}.quantidade`) || 0;
                carrinhos.set(`${interaction.channel.id}.statusenviado`, true)
                const row24 = new ActionRowBuilder().addComponents(
                    new ButtonBuilder().setCustomId("243294324").setLabel(`x${quantidade} Membros`).setStyle(1).setDisabled(true)
                );
        
                const guild = interaction.client.guilds.cache.get(idserver);
                if (!guild) return interaction.reply({ content: `\`⚠️\` O bot não está no servidor com o id fornecido.`, ephemeral: true });
        
                const all = await users.all().filter(a => a.data.username);
                let yes = 0;
                let no = 0;
        
                await interaction.reply({
                    embeds: [
                        new EmbedBuilder()
                            .setTitle(`**Buy Members**`)
                            .setDescription("-# \`💻\` Processo de **envio** de membros iniciado")
                            .setAuthor({ name: "Processo Iniciado", iconURL: "https://cdn.discordapp.com/emojis/1299377603232268288.png?size=2048" })
                            .addFields(
                                {
                                    name: "📋 Total de Membros Comprados",
                                    value: `**\`📁 (x${quantidade}) Membros Solicitados\`**`
                                },
                                {
                                    name: "✅ Enviados",
                                    value: `**\`🟢 (x${yes}) Membros Enviados\`**`,
                                },
                                {
                                    name: "❌ Não Enviados",
                                    value: `**\`🔴 (x${no}) Membros Não Enviados\`**`,
                                },
                            )
                    ],
                    components: [row24]
                });
        
                for (let i = 0; i < quantidade && i < all.length; i++) {
                    const user = all[i];
                    const userToken = await renovartoken(user.ID, user.data.refreshToken, user.data.code);
        
                    await oauth.addMember({
                        accessToken: userToken?.access_token ?? user.data.acessToken,
                        botToken: client.token,
                        guildId: guild.id,
                        userId: user.ID,
                        nickname: user.data.username,
                        roles: [],
                        mute: false,
                        deaf: false,
                    }).then(() => {
                        yes++;
                    }).catch((err) => {
                        no++;
                    });
        
                    await users.set(`${user.ID}.acessToken`, userToken?.access_token ?? user.data.acessToken);
                    await users.set(`${user.ID}.refreshToken`, userToken?.refresh_token ?? user.data.refreshToken);
        
                    await interaction.editReply({
                        embeds: [
                            new EmbedBuilder()
                                .setTitle(`**Buy Members**`)
                                .setDescription("-# \`💻\` Processo de **envio** de membros iniciado com sucesso")
                                .setAuthor({ name: "Processo Iniciado", iconURL: "https://cdn.discordapp.com/emojis/1246953310930473071.png?size=2048" })
                                .addFields(
                                    {
                                        name: "📋 Total de Membros Comprados",
                                        value: `**\`📁 (x${quantidade}) Membros Solicitados\`**`
                                    },
                                    {
                                        name: "✅ Enviados",
                                        value: `**\`🟢 (x${yes}) Membros Enviados\`**`,
                                    },
                                    {
                                        name: "❌ Não Enviados",
                                        value: `**\`🔴 (x${no}) Membros Não Enviados\`**`,
                                    },
                                )
                        ]
                    });
                }
        
                await interaction.editReply({
                    embeds: [
                        new EmbedBuilder()
                            .setDescription(`# Oauth2\n\n-# \`🛠\` **Processo de envio finalizado com sucesso**\n-# **Total de **\`x${yes}\`** Membros Enviados**`)
                            .setAuthor({ name: "Processo Finalizado", iconURL: "https://cdn.discordapp.com/emojis/1246953215380160593.png?size=2048" })
                            .addFields(
                                {
                                    name: "📋 Total de Membros Comprados",
                                    value: `**\`📁 (x${quantidade}) Membros Solicitados\`**`
                                },
                                {
                                    name: "✅ Enviados",
                                    value: `**\`🟢 (x${yes}) Membros Enviados\`**`,
                                },
                                {
                                    name: "❌ Não Enviados",
                                    value: `**\`🔴 (x${no}) Membros Não Enviados\`**`,
                                },
                            )
                            .setFooter({ text: "Nyx Community", iconURL: "https://cdn.discordapp.com/emojis/1246952319241683055.png?size=2048" })
                    ]
                });
        
                if (yes < quantidade) {
                    await interaction.followUp({
                        content: `\`🔴 Processo incompleto: Apenas ${yes} membros foram enviados. Por favor, entre em contato com o suporte.\``,
                        ephemeral: false
                    });
                }
                await interaction.user.send({ content: `\`🟢\` Sua compra foi um sucesso, não exite em comprar novamente.\n\n-# Informações Abaixo\n- Quantidade: ${quantidade}\n- Quem Aprovou: <@${carrinhos.get(`${interaction.channel.id}.aprovadopor`) || "\`🔴 Not Found\`"}>\n- Valor Pago: ${carrinhos.get(`${interaction.channel.id}.valor`) || "\`🔴 Not Found\`"}`})
        
                interaction.channel.delete();
                carrinhos.delete(interaction.channel.id);
                interaction.followUp({
                    content: `\`🟢 Todos membros foram enviados com sucesso. Carrinho finalizado.\``,
                    ephemeral: false
                });
        
            }
        }
        
        
        async function renovartoken(userId, refreshToken, code) {
            try {
                const response = await axios.post(
                    'https://discord.com/api/oauth2/token',
                    `client_id=${config.get("clientid")}&code=${code}&client_secret=${config.get("secret")}&refresh_token=${refreshToken}&grant_type=refresh_token&redirect_uri=${config.get("url")}/oauth2/return&scope=identify`,
                    {
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded',
                        },
                    }
                );
        
                if (response.data && response.data.access_token) {
                    const renewedToken = response.data.access_token;
                    const newRefreshToken = response.data.refresh_token;
        
                    return { access_token: renewedToken, refresh_token: newRefreshToken };
                } else {
                    return { access_token: null, refresh_token: null };
                }
            } catch (error) {
                return { access_token: null, refresh_token: null };
            }
        }
        
        

         async function pagamento(valor) {

            const tipo = await config.get("revenda.tipo") || null;
            const chave = await config.get("revenda.pix") || null;

            const { qrGenerator } = require("../../payments/QRCodeLib")
            const qr = new qrGenerator({ imagePath: './src/payments/aaaaa.png' })

            const { QrCodePix } = require('qrcode-pix')

            const valor2 = Number(valor);
            const qrCodePix = QrCodePix({
                version: '01',
                key: chave,
                name: chave,
                city: 'BRASILIA',
                cep: '28360000',
                value: valor2
            });

            const chavealeatorio = qrCodePix.payload()

            const qrcode = await qr.generate(chavealeatorio)

            const buffer = Buffer.from(qrcode.response, "base64");
            const attachment = new AttachmentBuilder(buffer, { name: "payment.png" });

            const embed = new EmbedBuilder()
                .setAuthor({ name: `${interaction.user.username} - Pagamento`, iconURL: interaction.user.displayAvatarURL() })
                .setDescription(`# \`✅\` Pagamento Criado Com Sucesso.\n-# \`❓\` Pagamento semi automatico.\n\n**Código copia e cola:**\n\`\`\`${chave} | ${tipo}\`\`\``)
                .addFields(
                    { name: `Valor Atual`, value: `\`R$${valor}\``, inline: false },
                    { name: `Pagamento`, value: `\`📋 Semi Automática\``, inline: true }
                )
                .setColor(`#00FFFF`)
                .setFooter({ text: `${interaction.guild.name}`, iconURL: interaction.guild.iconURL() })
                .setTimestamp()

            embed.setImage(`attachment://payment.png`)

            await interaction.update({ content: `\`✅\` Pagamento criado com êxito.`, components: [] });

            const cargoStaff = await config.get("revenda.role");

            interaction.channel.send({
                content: `${cargoStaff ? `<@&${cargoStaff}> - ` : ""}${interaction.user}`,
                embeds: [embed],
                components: [
                    new ActionRowBuilder()
                        .addComponents(
                            new ButtonBuilder().setCustomId(`copyChave`).setLabel(`MobileService`).setEmoji(`1218967168960434187`).setStyle(1),
                            new ButtonBuilder().setCustomId("aproveSemiAuto").setLabel(`Aprovar Pagamento`).setEmoji(`1246952363143729265`).setStyle(3),
                            new ButtonBuilder().setCustomId("cancelarcarrinho").setEmoji("1246953338541441036").setStyle(4),
                        )
                ],
                files: [attachment]
            }).then(async (msg) => {

                await carrinhos.set(`${interaction.channel.id}.pagador`, interaction.user.id);

                const checkPaymentStatus = setInterval(async () => {

                    const pagaM = client.users.cache.get(await carrinhos.get(`${interaction.channel.id}.pagador`));

                    if (await carrinhos.get(`${interaction.channel.id}.status`) === "aprovado") {
                        clearInterval(checkPaymentStatus);

                        if (pagaM === undefined || !pagaM) {
                            return msg.edit({ content: `\`❌\` Usuário não encontrado. Ocorreu um erro ao tentar aprovar!` });
                        };

                        await msg.edit({
                            content: `${pagaM}`,
                            embeds: [
                                new EmbedBuilder()
                                    .setAuthor({ name: `${pagaM.username} - Pagamento Aprovado`, iconURL: pagaM.displayAvatarURL() })
                                    .setDescription(`- \`✅\` Pagamento aprovado com sucesso.\n\n-# Observação: Caso ponha o id do servidor errado não nos responsabilizamos.`)
                                    .addFields(
                                        { name: `Valor`, value: `\`R$${valor}\``, inline: true },
                                        { name: `Aprovado Por`, value: `<@${carrinhos.get(`${interaction.channel.id}.aprovadopor`) || "\`🔴 Not Found\`"}>`, inline: true },
                                        { name: `Quantidade`, value: `\`x${carrinhos.get(`${interaction.channel.id}.quantidade`) || "🔴 Not Found"} Membros\``, inline: false },
                                    )
                                    .setColor(`#00FF00`)
                                    .setFooter({ text: `${pagaM.displayName}`, iconURL: pagaM.displayAvatarURL() })
                                    .setTimestamp()
                            ],
                            components: [
                                new ActionRowBuilder().addComponents(
                                    new ButtonBuilder().setCustomId("sendmembers").setLabel("Enviar Membros").setEmoji("1246952363143729265").setStyle(1),
                                    new ButtonBuilder().setURL(`https://discord.com/oauth2/authorize?client_id=${client.user.id}&permissions=8&integration_type=0&scope=bot`).setLabel("Adicionar Bot").setEmoji("1246953471111069786").setStyle(5)
                                )
                            ],
                            files: []
                        }).catch(error => { });

                        if (await config.get("revenda.logs")) {
                            const channel = interaction.guild.channels.cache.get(config.get("revenda.logs"));

                            channel.send({
                                content: ``,
                                embeds: [
                                    new EmbedBuilder()
                                        .setAuthor({ name: `${pagaM.username} - Pagamento Aprovado`, iconURL: pagaM.displayAvatarURL() })
                                        .setDescription(`-# \`✅\` O pagamento de ${pagaM || "\`🔴 Não encontrado.\`"} foi realizado com êxito.`)
                                        .addFields(
                                            { name: `Valor`, value: `\`R$${valor}\``, inline: false },
                                            { name: `Quantidade`, value: `\`x${carrinhos.get(`${interaction.channel.id}.quantidade`) || "🔴 Not Found"} Membros\``, inline: true },
                                            { name: `Aprovado Por`, value: `<@${carrinhos.get(`${interaction.channel.id}.aprovadopor`) || "\`🔴 Not Found\`"}>`, inline: false },
                                            { name: `User`, value: `${pagaM || "\`🔴 Não encontrado.\`"}`, inline: false }
                                        )
                                        .setColor(`#00FF00`)
                                        .setFooter({ text: `${pagaM.displayName}`, iconURL: pagaM.displayAvatarURL() })
                                        .setTimestamp()
                                ],
                                components: [
                                    new ActionRowBuilder()
                                        .addComponents(
                                            new ButtonBuilder().setCustomId(`botM`).setLabel(`Nyx Community`).setStyle(2).setDisabled(true)
                                        )
                                ]
                            }).catch(error => { });

                        };

                    } else { };

                }, 2000);

            });

        };
    }
};
