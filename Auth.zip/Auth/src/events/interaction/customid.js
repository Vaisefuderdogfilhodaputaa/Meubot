const { ApplicationCommandType, EmbedBuilder, ModalBuilder, TextInputBuilder, ActionRowBuilder, TextInputStyle, ChannelSelectMenuBuilder, ChannelType, ButtonBuilder, RoleSelectMenuBuilder, UserSelectMenuBuilder, StringSelectMenuBuilder } = require("discord.js");
const { config, message } = require("../../DataBaseJson");
const { painel, sendembed, infoimportantes, configembed, infoembed, avancados } = require("../../functions/painel");
const discordOauth = require("discord-oauth2");
const { revenda, blacklist } = require("../../functions/revenda");
const oauth = new discordOauth();
async function resetarDB() {
    try {
        const todaskeys2024 = await config.all();
        const promises = todaskeys2024.map(entry => config.delete(entry.ID));
        await Promise.all(promises);
    } catch (error) {
    }
}

module.exports = {
    name: "interactionCreate",
    run: async (interaction, client) => {
        const { customId } = interaction;
        if (!customId) return;

        if (customId === 'opcavandos' && interaction.values.includes('configrevenda')) {
            revenda(interaction, client)
        };

        if (customId === 'opcavandos' && interaction.values.includes('blacklist2024')) {
            blacklist(interaction, client)
        };

        if (customId === "revendasvoltar2024") {
            revenda(interaction, client)
        }

        if (customId === "blacklistvoltar2024") {
            blacklist(interaction, client)
        }

        if (customId === "avancados") {
            avancados(interaction, client);
        };

        if (customId === "voltar00") {
            painel(interaction, client);
        };

        if (customId === "config01") {
            configembed(interaction, client);
        };

        if (customId === "info") {
            infoembed(interaction, client);
        };

        if (customId === "sendembed") {
            sendembed(interaction, client);
        };

        if (customId === "infoimportantes") {
            infoimportantes(interaction, client);
        };

        if (customId === "resetinfos") {
            resetarDB();
            infoembed(interaction, client);
        };

        if (customId === "onoff") {
            const status2024 = config.get("revenda.status") || false
            const resultado2024 = !status2024
            config.set("revenda.status", resultado2024)
            revenda(interaction, client);
        };

        if (customId === "trocarmessage") {
            const status2024 = message.get("status") || false
            const resultado2024 = !status2024
            message.set("status", resultado2024)
            sendembed(interaction, client);
        };

        if (customId === "configcontent") {
            const message24 = message.get("status") || false;

            if (message24) {

            const modal = new ModalBuilder()
                .setCustomId('configcontentmodal')
                .setTitle('Configurar content');
        
            const inputcontent2024 = new TextInputBuilder()
                .setCustomId('contentinput')
                .setLabel('Mensagem  (Obrigatorio)')
                .setPlaceholder("Mensagem de verificação")
                .setStyle(TextInputStyle.Short)
                .setValue(message.get("message.mensagem") || "")
                .setMaxLength(400)
                .setRequired(true);
    
            const inputbanner2024 = new TextInputBuilder()
                .setCustomId('contentbannerinput')
                .setLabel('Banner (opcional)')
                .setPlaceholder("Use \"Remover\" para remover")
                .setValue(message.get("message.banner") || "")
                .setStyle(TextInputStyle.Short)
                .setRequired(false);
        
            const row24 = new ActionRowBuilder().addComponents(inputcontent2024);
            const row244 = new ActionRowBuilder().addComponents(inputbanner2024);
            modal.addComponents(row24, row244);
        
            await interaction.showModal(modal);
        } else {
            const modal = new ModalBuilder()
            .setCustomId('configembedmodal')
            .setTitle('Configurar Embed');
    
        const titleInput = new TextInputBuilder()
            .setCustomId('embedTitle')
            .setLabel('Titulo')
            .setStyle(TextInputStyle.Short)
            .setPlaceholder("Insira o titulo da embed")
            .setValue(message.get("embed.title") || "")
            .setMaxLength(100)
            .setRequired(true);
    
        const descriptionInput = new TextInputBuilder()
            .setCustomId('embedDescription')
            .setLabel('Descrição')
            .setStyle(TextInputStyle.Paragraph)
            .setPlaceholder("Insira a descrição da embed")
            .setValue(message.get("embed.description") || "")
            .setMaxLength(500)
            .setRequired(true);
    
        const bannerInput = new TextInputBuilder()
            .setCustomId('embedBanner')
            .setLabel('Banner')
            .setStyle(TextInputStyle.Short)
            .setPlaceholder("Use \"Remover\" para remover")
            .setValue(message.get("embed.banner") || "")
            .setRequired(false);
    
        const footerInput = new TextInputBuilder()
            .setCustomId('embedFooter')
            .setLabel('Footer')
            .setStyle(TextInputStyle.Short)
            .setMaxLength(24)
            .setPlaceholder("Insira o footer da embed (opcional)")
            .setValue(message.get("embed.footer") || "")
            .setRequired(false);
    
        const colorInput = new TextInputBuilder()
            .setCustomId('embedColor')
            .setLabel('Insira a cor da embed (opcional)')
            .setStyle(TextInputStyle.Short)
            .setPlaceholder("#000000")
            .setValue(message.get("embed.color") || "")
            .setRequired(false);

        modal.addComponents(
            new ActionRowBuilder().addComponents(titleInput),
            new ActionRowBuilder().addComponents(descriptionInput),
            new ActionRowBuilder().addComponents(bannerInput),
            new ActionRowBuilder().addComponents(footerInput),
            new ActionRowBuilder().addComponents(colorInput)
        );
    
        await interaction.showModal(modal);
        }
    }

    if (customId === "configclientid") {
        config.set("clientid", client.user.id)
        await interaction.reply({ content: `\`✅\` O id do bot foi pego automaticamente: \`${client.user.id}\``, ephemeral: true })
    }

    if (customId === "configguild") {
        config.set("guild_id", interaction.guild.id)
        await interaction.reply({ content: `\`✅\` O id do server foi pego automaticamente: \`${interaction.guild.id}\``, ephemeral: true })
    }

    if (customId === "configsecret") {
        const modal = new ModalBuilder()
        .setCustomId('configsecretbot')
        .setTitle('Secret Bot');

    const secretinput2024 = new TextInputBuilder()
        .setCustomId('secretinput2024')
        .setLabel('Secret Bot')
        .setPlaceholder("Insira o Client Secret do bot.")
        .setStyle(TextInputStyle.Short)
        .setMaxLength(400)
        .setRequired(true);

    const row24 = new ActionRowBuilder().addComponents(secretinput2024);
    modal.addComponents(row24);

    await interaction.showModal(modal);
    }

    if (customId === "configurl") {
        const modal = new ModalBuilder()
        .setCustomId('configurl2024')
        .setTitle('Url');

    const urlinput2024 = new TextInputBuilder()
        .setCustomId('configurlinput2024')
        .setLabel('Url Verify')
        .setPlaceholder("Insira a url de verificação.")
        .setStyle(TextInputStyle.Short)
        .setMaxLength(400)
        .setRequired(true);

    const row24 = new ActionRowBuilder().addComponents(urlinput2024);
    modal.addComponents(row24);

    await interaction.showModal(modal);
    }

    if (customId === "configredirect") {
        const modal = new ModalBuilder()
        .setCustomId('configredirect2024')
        .setTitle('Redirect');

    const urlinput2024 = new TextInputBuilder()
        .setCustomId('configredirect2024input')
        .setLabel('Site Redirect')
        .setPlaceholder("Insira a url do site de verificação concluida.")
        .setStyle(TextInputStyle.Short)
        .setMaxLength(400)
        .setRequired(true);

    const row24 = new ActionRowBuilder().addComponents(urlinput2024);
    modal.addComponents(row24);

    await interaction.showModal(modal);
    }


    if (interaction.isModalSubmit()) {

        if (interaction.customId === "configredirect2024") {
            const url = interaction.fields.getTextInputValue("configredirect2024input");
            config.set("redirect", url)
            await interaction.reply({ content: `\`🟢\` Nova Url Configurada: \`${url}\``, ephemeral: true })
        }

        if (interaction.customId === "configurl2024") {
            const url = interaction.fields.getTextInputValue("configurlinput2024");
            config.set("url", url)
            await interaction.reply({ content: `\`🟢\` Nova Url Configurada: \`${url}\``, ephemeral: true })
        }

        if (interaction.customId === "configsecretbot") {
            const secretid = interaction.fields.getTextInputValue("secretinput2024");
            config.set("secret", secretid)
            await interaction.reply({ content: `\`🟢\` Novo Client Secret: \`${secretid}\``, ephemeral: true })
        }

        if (interaction.customId === "configcontentmodal") {
            const mensagem = interaction.fields.getTextInputValue("contentinput");
            const banner = interaction.fields.getTextInputValue("contentbannerinput");
    
            function linkValido(url) {
                const urlRegex = /^(https?|ftp):\/\/[^\s/$.?#].[^\s]*$/;
                return urlRegex.test(url);
            }
    
            if (banner === "remover") {
                message.delete("message.banner");
                return sendembed(interaction, client);
            }
    
            if (banner && !linkValido(banner)) {
                return interaction.reply({ content: "`🔴 A Imagem Inserida é Inválida.`", ephemeral: true });
            }
    
            if (banner) {
                message.set("message.banner", banner);
            }
            message.set("message.mensagem", mensagem);
    
            sendembed(interaction, client);
        }

        if (interaction.customId === "configembedmodal") {
            const title = interaction.fields.getTextInputValue("embedTitle");
            const description = interaction.fields.getTextInputValue("embedDescription");
            const banner = interaction.fields.getTextInputValue("embedBanner");
            const footer = interaction.fields.getTextInputValue("embedFooter");
            const color = interaction.fields.getTextInputValue("embedColor") || "#000000";
        
            function linkValido(url) {
                const urlRegex = /^(https?|ftp):\/\/[^\s/$.?#].[^\s]*$/;
                return urlRegex.test(url);
            }
        
            function corValida(cor) {
                const corRegex = /^#[0-9A-Fa-f]{6}$/;
                return corRegex.test(cor);
            }
        
            if (banner === "remover") {
                message.delete("embed.banner");
                return sendembed(interaction, client);
            }
        
            if (banner && !linkValido(banner)) {
                return interaction.reply({ content: "`🔴 A Imagem Inserida é Inválida.`", ephemeral: true });
            }
        
            if (color && !corValida(color)) {
                return interaction.reply({ content: "`🔴 A Cor Inserida é Inválida.`", ephemeral: true });
            }
        
            message.set("embed.title", title);
            message.set("embed.description", description);
            if (banner) {
                message.set("embed.banner", banner);
            }
            if (footer) {
                message.set("embed.footer", footer);
            }
            if (color) {
                message.set("embed.color", color);
            }
        
            sendembed(interaction, client);
        }
    }

    if (customId === "postarmsg") {
    
        const selectmenu2024 = new ChannelSelectMenuBuilder()
            .setCustomId('selecionarcanalpostar')
            .setPlaceholder('Postar Mensagem')
            .addChannelTypes(0);
    
        const row = new ActionRowBuilder().addComponents(selectmenu2024);

        const message24 = message.get("status") || false;
    
        await interaction.reply({
            content: `\`🟢 Escolha o canal que a ${message24 ? "Mensagem" : "Embed"}:\``,
            components: [row],
            ephemeral: true
        });
    }

    if (customId === "configlogs") {
    
        const selectmenu2024 = new ChannelSelectMenuBuilder()
            .setCustomId('canallogs2024')
            .setPlaceholder('Canal de Logs')
            .addChannelTypes(0);
    
        const row = new ActionRowBuilder().addComponents(selectmenu2024);
    
        await interaction.reply({
            content: `\`🟢 Escolha o canal de logs verificados\``,
            components: [row],
            ephemeral: true
        });
    }

    if (customId === "configlgs") {
    
        const selectmenu2024 = new ChannelSelectMenuBuilder()
            .setCustomId('configlogs2024')
            .setPlaceholder('Canal de Logs Vendas')
            .addChannelTypes(0);
    
        const row = new ActionRowBuilder().addComponents(selectmenu2024);
        const row4 = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId("revendasvoltar2024").setEmoji("1246955006242983936").setStyle(2)
          );
    
        await interaction.update({
            content: `\`🟢 Escolha o canal de logs das vendas\``,
            components: [row, row4],
            embeds: [],
            ephemeral: true
        });
    }

    if (customId === "configrole") {
        const selectmenu2024 = new RoleSelectMenuBuilder()
            .setCustomId('cargodeverificado2024')
            .setPlaceholder('Escolha o cargo de verificado');
    
        const row = new ActionRowBuilder().addComponents(selectmenu2024);
    
        await interaction.reply({
            content: "`🟢 Escolha o cargo de verificado`",
            components: [row],
            ephemeral: true
        });
    }

    if (customId === "configcrg") {
        const selectmenu2024 = new RoleSelectMenuBuilder()
            .setCustomId('cargoaprovador2024')
            .setPlaceholder('Escolha o cargo de aprovador');
    
        const row = new ActionRowBuilder().addComponents(selectmenu2024);
        const row4 = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId("revendasvoltar2024").setEmoji("1246955006242983936").setStyle(2)
          );
    
        await interaction.update({
            content: "`🟢 Escolha o cargo que pode aprovar um carrinho`",
            components: [row, row4],
            embeds: [],
            ephemeral: true
        });
    }

    if (interaction.isRoleSelectMenu()) {
        if (interaction.customId === "cargodeverificado2024") {
            const cargoselecionado2024 = interaction.values[0];
            config.set("role", cargoselecionado2024)
            interaction.update({ content: "`✅ Cargo de verificado configurado com sucesso.`", components: [], ephemeral: true });
        }

        if (interaction.customId === "cargoaprovador2024") {
            const cargoselecionado2024 = interaction.values[0];
            config.set("revenda.role", cargoselecionado2024)
            revenda(interaction, client)
        }
    }

    if (interaction.isChannelSelectMenu()) {

        if (interaction.customId === "configlogs2024") {
            const canalid2024 = interaction.values[0];
            const canal = interaction.guild.channels.cache.get(canalid2024);
        
            if (!canal) {
                return interaction.update({ content: "`🔴 O canal selecionado não foi encontrado.`", components: [], ephemeral: true });
            }

            config.set("revenda.logs", canal.id)
            revenda(interaction, client)

        }

        if (interaction.customId === "canallogs2024") {
            const canalid20244 = interaction.values[0];
            const canal = interaction.guild.channels.cache.get(canalid20244);
        
            if (!canal) {
                return interaction.update({ content: "`🔴 O canal selecionado não foi encontrado.`", components: [], ephemeral: true });
            }
        
            const servernome2024 = interaction.guild.name;
        
            try {
                const webhook = await canal.createWebhook({
                    name: servernome2024,
                    avatar: interaction.user.displayAvatarURL({ format: 'png' }),
                });
        
                interaction.update({ content: "`✅ Canal de logs configurado com sucesso.`", components: [], ephemeral: true });
        
                config.set("webhook_logs", webhook.url);
            } catch (error) {
                interaction.update({ content: "`🔴 Ocorreu um erro ao criar o webhook.`", components: [], ephemeral: true });
            }
        }

        if (interaction.customId === "selecionarcanalpostar") {
            const canalselecionado = interaction.values[0];
            const channel = interaction.guild.channels.cache.get(canalselecionado);
    
            if (!channel) {
                return interaction.update({ content: "`🔴 O canal selecionado não foi encontrado.`", components: [], ephemeral: true });
            }

            const row = new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId("linkverify2024").setLabel("Se Verificar").setEmoji("1231409179810598943").setStyle(2)
            )
    
            const embeddata = message.get("embed") || {};
            const messagedata = message.get("message") || {};
            const status = message.get("status") || false;
    
            if (!status) { 
                const embed = new EmbedBuilder()
                    .setTitle(embeddata.title || "`🔴 Não Encontrado.`")
                    .setDescription(embeddata.description || "`🔴 Não Encontrado.`")
                    .setFooter({ text: embeddata.footer || "Não Configurado..." })
                    .setColor(embeddata.color || "#000000");
    
                if (embeddata.banner) embed.setImage(embeddata.banner);
    
                channel.send({ embeds: [embed], components: [row] });
            } else {
                const bannerMessage = messagedata.banner ? `[banner](${messagedata.banner})` : "";
                channel.send({ content: `${messagedata.mensagem || "`🔴 Não Encontrado.`"}\n\n${bannerMessage}`, components: [row] });
            }
    
            interaction.update({ content: "`✅ Mensagem postada com sucesso!`", components: [], embeds: [], ephemeral: true });
        }
    }

    if (customId === "addblacklist") {
      
        const row24 = new ActionRowBuilder().addComponents(
            new UserSelectMenuBuilder().setCustomId("blacklistusers2024").setPlaceholder("Adicionar Usuarios Na Blacklist").setMinValues(1).setMaxValues(8)
        );

        const row244 = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId("blacklistvoltar2024").setEmoji("1246955006242983936").setStyle(2)
          );
      
        await interaction.update({
          content: "\`🟢 Selecione ate 8 usuarios no maximo para adicionar na blacklist:\`",
          components: [row24, row244],
          embeds: [],
          ephemeral: true,
        });
      }

      if (interaction.isUserSelectMenu()) {
        if (interaction.customId === "blacklistusers2024") {

          const usuarios2024 = interaction.values;
          config.set("blacklist.users", usuarios2024);
          
          await blacklist(interaction, client);
        }
      }

      
      if (customId === "listablacklist2024") {
        const usuarios2024 = config.get("blacklist.users") || [];
        let content2024 = "## Lista de usuarios na blacklist\n- Usuarios abaixo\n";
        
        for (const userId of usuarios2024) {
          try {
            const usuario = await interaction.guild.members.fetch(userId);
            content2024 += `\`📋 ${usuario.user.username} - ${userId}\`\n`;
          } catch {
            content2024 += `\`📋 Usuário não encontrado - ${userId}\`\n`;
          }
        }
        
        const row24 = new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId("removertodos").setLabel("Retirar Todos").setEmoji("1246953338541441036").setStyle(4),
          new ButtonBuilder().setCustomId("blacklistvoltar2024").setEmoji("1246955006242983936").setStyle(2)
        );
        
        if (usuarios2024.length === 0) {
            content2024 += "\n\`🔴 Nenhum usuário na blacklist.\`";
        }
      
        await interaction.update({
          content: content2024,
          components: [row24],
          embeds: [],
          ephemeral: true
        });
      }

      if (customId === "remblacklist") {

        const modal = new ModalBuilder()
          .setCustomId('remblacklist_modal')
          .setTitle('Remover Usuário da Blacklist');

        const userinput2024 = new TextInputBuilder()
          .setCustomId('userremblacklist2024')
          .setLabel("Insira o id do usuario")
          .setStyle(TextInputStyle.Short)
          .setPlaceholder('Ex: Id4')
          .setRequired(true);
      
        const row = new ActionRowBuilder().addComponents(userinput2024);
        
        modal.addComponents(row);
      
        await interaction.showModal(modal);
      }

      
      if (interaction.isModalSubmit()) {
        if (interaction.customId === 'remblacklist_modal') {
          const idusuario20242 = interaction.fields.getTextInputValue('userremblacklist2024');
          
          let db2024 = config.get("blacklist.users") || [];
          db2024 = db2024.filter(id => id !== idusuario20242);
          config.set("blacklist.users", db2024);

          blacklist(interaction, client)
        }
      }
      

    if (customId === "removertodos") {
        config.delete("blacklist.users")
        blacklist(interaction, client)
    }
      
      

    if (customId === "linkverify2024") {
        const url = oauth.generateAuthUrl({
            clientId: config.get("clientid") || client.user.id,
            clientSecret: config.get("secret") || null,
            scope: ["identify", "email", "guilds.join"],
            redirectUri: `${config.get("url") || "Não Definido"}/oauth2/return`
        });

        const row24 = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setLabel("Link").setEmoji("1246953471111069786").setStyle(5).setURL(url)
        )

        await interaction.reply({ components: [row24], ephemeral: true })
    }

    if (customId === "resetarallconfigs") {
        message.delete("message")
        message.delete("embed")
        message.delete("status")
        sendembed(interaction, client)
    }


    if (customId === "4324configpix") {
    const modal = new ModalBuilder()
        .setCustomId('configpixmodal')
        .setTitle('Chave Pix');

    const inputpix = new TextInputBuilder()
        .setCustomId('pixinput')
        .setLabel('Pix')
        .setPlaceholder("Ex: Nyxcommunity@gmail.com")
        .setStyle(TextInputStyle.Short)
        .setMaxLength(200)
        .setRequired(true);

    const inputtipo = new TextInputBuilder()
        .setCustomId('tipoinput')
        .setLabel('Tipo')
        .setPlaceholder("Ex: Email, Telefone, Cpf.")
        .setStyle(TextInputStyle.Short)
        .setRequired(true);

    const valor = new TextInputBuilder()
        .setCustomId('valorinput')
        .setLabel('Valor de 10 membros')
        .setPlaceholder("Ex: Nâo utilize , utilize . ex: 2.40")
        .setStyle(TextInputStyle.Short)
        .setRequired(true);

    const row244 = new ActionRowBuilder().addComponents(inputpix);
    const row2444 = new ActionRowBuilder().addComponents(inputtipo);
    const row24 = new ActionRowBuilder().addComponents(valor);
    modal.addComponents(row244, row2444, row24);

    await interaction.showModal(modal);
    }

    if (interaction.isModalSubmit()) {
        if (interaction.customId === "configpixmodal") {
            const pix = interaction.fields.getTextInputValue("pixinput");
            const tipo = interaction.fields.getTextInputValue("tipoinput");
            const valor = interaction.fields.getTextInputValue("valorinput");
            config.set("revenda.pix", pix)
            config.set("revenda.tipo", tipo)
            config.set("revenda.valor", valor)
            revenda(interaction, client)
        }
    }
    

    }
};
