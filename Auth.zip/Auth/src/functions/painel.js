const { EmbedBuilder, ApplicationCommandType, ActionRowBuilder, ButtonBuilder, StringSelectMenuBuilder } = require("discord.js");
const { config, message, users } = require("../DataBaseJson");
const discordOauth = require("discord-oauth2");
const oauth = new discordOauth();



async function painel(interaction, client) {

    const url = oauth.generateAuthUrl({
        clientId: config.get("clientid") || client.user.id,
        clientSecret: config.get("secret"),
        scope: ["identify", "email", "guilds.join"],
        redirectUri: `${config.get("url")}/oauth2/return`
    });

    const ping2024 = client.ws.ping

    const embed = new EmbedBuilder()
    .setAuthor({ name: `${interaction.user.username} - Gerenciamento Oauth2`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
    .setTitle("**Oauth2**")
    .setDescription("-# \`🔧\` Gerencie seu **Oauth2** aqui.")
    .addFields(
      { name: "\`Versão Atual\`", value: "**\`3.0.0\`**", inline: true },
      { name: "\`Ping\`", value: `**\`${ping2024}\`**`, inline: true }
    )
    .setFooter({ text:`NyX Community - Todos os Direitos reservados`, iconURL: interaction.guild.iconURL({ dynamic: true }) })

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId("config01").setLabel("Configurações").setEmoji("1246953456368095232").setStyle(1),
      new ButtonBuilder().setCustomId("info").setLabel("Informações").setEmoji("1246954960218886146").setStyle(2),
      new ButtonBuilder().setCustomId("sendembed").setLabel("Postar").setEmoji("1246953484243173397").setStyle(3),
      new ButtonBuilder().setCustomId("infoimportantes").setEmoji("1246954883182100490").setStyle(1)
    )




  if (interaction.message == undefined) {
    interaction.reply({ content: ``, components: [row], content: '', embeds: [embed], ephemeral: true })
  } else {
    interaction.update({ content: ``, components: [row], content: '', embeds: [embed], ephemeral: true })
  }
}

async function configembed(interaction, client) {

  const url = oauth.generateAuthUrl({
      clientId: config.get("clientid") || client.user.id,
      clientSecret: config.get("secret"),
      scope: ["identify", "email", "guilds.join"],
      redirectUri: `${config.get("url") || "Não Definido"}/oauth2/return`
  });

  const embed = new EmbedBuilder()
  .setAuthor({ name: `${interaction.user.username} - Configuração Oauth2`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
  .setTitle("**Oauth2 Config**")
  .setDescription("-# \`💻\` Configure o sistema **Oauth2** aqui.")
  .setFooter({ text:`NyX Community - Todos os Direitos reservados`, iconURL: interaction.guild.iconURL({ dynamic: true }) })

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId("configclientid").setLabel("Client ID").setEmoji("1218968026251001896").setStyle(1),
    new ButtonBuilder().setCustomId("configsecret").setLabel("Secret").setEmoji("1218968026251001896").setStyle(1),
    new ButtonBuilder().setCustomId("configurl").setLabel("URL").setEmoji("1246953149009367173").setStyle(1),
    new ButtonBuilder().setCustomId("configredirect").setLabel("Site Verify").setEmoji("1246953471111069786").setStyle(1)
  );
  
  const row2 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId("configlogs").setLabel("Logs").setEmoji("1287481024141590619").setStyle(2),
    new ButtonBuilder().setCustomId("configrole").setLabel("Cargo").setEmoji("1246953373488382094").setStyle(2),
    new ButtonBuilder().setCustomId("configguild").setLabel("Server").setEmoji("1246953187529855037").setStyle(2)
  );
  
  const row3 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId("voltar00").setEmoji("1246955006242983936").setStyle(2)
  );

  interaction.update({ content: ``, components: [row, row2, row3], content: '', embeds: [embed], ephemeral: true })
}

async function infoembed(interaction, client) {

  const url = oauth.generateAuthUrl({
      clientId: config.get("clientid") || client.user.id,
      clientSecret: config.get("secret"),
      scope: ["identify", "email", "guilds.join"],
      redirectUri: `${config.get("url") || "Não Definido"}/oauth2/return`
  });

  const embed = new EmbedBuilder()
  .setAuthor({ name: `${interaction.user.username} - Informações`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
  .setTitle("**Info Oauth2**")
  .setDescription("-# \`📁\` Informações do seu **Oauth2** aqui.")
  .addFields(
    { name: "**URL**", value: `\`${config.get("url") || "Não Configurado"}\``, inline: true },
    { name: "**Site de Verify**", value: `\`${config.get("redirect") || "Não Configurado"}\``, inline: true },
    { name: "\u200B", value: "\u200B", inline: true },
    { name: "**Bot ID**", value: `\`${config.get("clientid") || "Não Configurado"}\``, inline: true },
    { name: "**Secret Bot**", value: `\`${config.get("secret") || "Não Configurado"}\``, inline: true },
    { name: "\u200B", value: "\u200B", inline: true },
    { name: "**Server ID**", value: `\`${config.get("guild_id") || "Não Configurado"}\``, inline: true },
    { name: "**Cargo**", value: `${config.get("role") ? `<@&${config.get("role")}>` : "`Não Configurado`"}`, inline: true },
    { name: "\u200B", value: "\u200B", inline: true },
    { name: "**Webhook Logs**", value: `${config.get("webhook_logs") ? `\`\`\`${config.get("webhook_logs")}\`\`\`` : "`Não Configurado`"}`, inline: false }
)

  .setFooter({ text: `NyX Community - Todos os Direitos reservados`, iconURL: interaction.guild.iconURL({ dynamic: true }) });


  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId("resetinfos").setLabel("Resetar").setEmoji("1231409365890760774").setStyle(4),
    new ButtonBuilder().setCustomId("voltar00").setEmoji("1246955006242983936").setStyle(2)
  );
  
  interaction.update({ content: ``, components: [row], content: '', embeds: [embed], ephemeral: true })
}


async function infoimportantes(interaction, client) {
  const url = config.get("url");
  const secret = config.get("secret");

  const row24 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId("voltar00").setEmoji("1246955006242983936").setStyle(2)
  );

  if (!url || !secret) {
    return interaction.update({
      content: "",
      components: [row24],
      embeds: [
        new EmbedBuilder()
          .setAuthor({ name: `${interaction.user.username} - Informações`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
          .setTitle("**Info Oauth2**")
          .setDescription(`# Total de usuarios verificados: (**${(await users.all()).filter(a => a.data.username).length}**)\n-# \`🟢\` Informações do seu **Oauth2** aqui.`)
          .addFields(
            { name: "**Url Dev**", value: "`🔴 Não Configurado`", inline: false },
            { name: "**Url Oauth2**", value: "`🔴 Não Configurado`", inline: false }
          )
          .setFooter({ text: `NyX Community - Todos os Direitos reservados`, iconURL: interaction.guild.iconURL({ dynamic: true }) })
      ],
      ephemeral: true
    });
  }

  const url2024 = oauth.generateAuthUrl({
    clientId: config.get("clientid") || client.user.id,
    clientSecret: config.get("secret"),
    scope: ["identify", "email", "guilds.join"],
    redirectUri: `${config.get("url")}/oauth2/return`
  });

  const all = await users.all().filter(a => a.data.username);

  const embed = new EmbedBuilder()
    .setAuthor({ name: `${interaction.user.username} - Informações`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
    .setTitle("**Info Oauth2**")
    .setDescription(`# Total de usuarios verificados: (**${all.length}**)\n-# \`🟢\` Informações do seu **Oauth2** aqui.`)
    .addFields(
      { name: "**Url Dev**", value: `${url ? `\`\`${url}/oauth2/return\`\`` : "\`🔴 Não Configurado\`"}`, inline: false },
      { name: "**Url Oauth2**", value: `\`\`\`${url2024}\`\`\``, inline: false },
    )
    .setFooter({ text: `NyX Community - Todos os Direitos reservados`, iconURL: interaction.guild.iconURL({ dynamic: true }) });

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId("avancados").setLabel("Revenda").setEmoji("1246954960218886146").setStyle(1),
    new ButtonBuilder().setCustomId("voltar00").setEmoji("1246955006242983936").setStyle(2)
  );

  interaction.update({ content: "", components: [row], embeds: [embed], ephemeral: true });
}


async function sendembed(interaction, client) {
  const message24 = message.get("status") || false;
 
  const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId("configcontent").setLabel(`Configurar ${message24 ? "Content" : "Embed"}`).setEmoji("1246954960218886146").setStyle(2),
      new ButtonBuilder().setCustomId("trocarmessage").setLabel(message24 ? "Modo Content" : "Modo Embed").setEmoji("1246953228655132772").setStyle(1),
      new ButtonBuilder().setCustomId("postarmsg").setLabel(message24 ? "Postar Mensagem" : "Postar Embed").setEmoji("1246953484243173397").setStyle(3),
      new ButtonBuilder().setCustomId("resetarallconfigs").setLabel("Resetar Configurações").setEmoji("1246953338541441036").setStyle(4),
      new ButtonBuilder().setCustomId("voltar00").setEmoji("1246955006242983936").setStyle(2),
  );
 
  if (message24) {
    const content = `${message.get("message.mensagem") || "\`🔴 Não Configurado.\`"}`
    const bannerMessage = message.get("message.banner") || ""
    
    await interaction.update({ content: `${content}\n\n${bannerMessage ? `[banner](${message.get("message.banner")})` : ""}`, components: [row], embeds: [], ephemeral: true });
  } else {
      const embed = new EmbedBuilder()
          .setTitle(message.get("embed.title") || "\`🔴 Não Encontrado.\`")
          .setDescription(message.get("embed.description") || "\`🔴 Não Encontrado.\`")
          .setThumbnail(message.get("embed.banner") || null)
          .setFooter({ text: message.get("embed.footer") || "Não Configurado..." })
          .setColor(message.get("embed.color") || "NotQuiteBlack");

      
      await interaction.update({ content: "", components: [row], embeds: [embed], ephemeral: true });
  }
 }

 async function avancados(interaction, client) {
  const embed = new EmbedBuilder()
    .setAuthor({ name: `${interaction.user.username} - Revenda`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
    .setDescription(`# Revenda Membros\n-# \`🟢\` Acesse sistemas de revenda de membros do seu **Oauth2** abaixo.`)
    .setFooter({ text: `NyX Community - Todos os Direitos reservados`, iconURL: interaction.guild.iconURL({ dynamic: true }) });
  
  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId("infoimportantes")
      .setEmoji("1246955006242983936")
      .setStyle(2)
  );

  const selectmenu2024 = new ActionRowBuilder().addComponents(
    new StringSelectMenuBuilder()
    .setCustomId("opcavandos")
    .setPlaceholder("🛠 Opções Avançadas")
    .addOptions([
      {
        label: "Configurar Revenda",
        description: "Configurar o sistema de revenda de membros.",
        emoji: "1246954913729220628",
        value: "configrevenda",
      },
      {
        label: "Adicionar Blacklist",
        description: "O usuario não conseguirar abrir carrinho.",
        emoji: "1246954883182100490",
        value: "blacklist2024",
      },
    ])
  );
  
  await interaction.update({ 
    content: "", 
    components: [selectmenu2024, row], 
    embeds: [embed], 
    ephemeral: true 
  });
}




module.exports = {
    painel,
    configembed,
    infoembed,
    infoimportantes,
    sendembed,
    avancados
}
