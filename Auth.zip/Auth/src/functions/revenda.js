const { EmbedBuilder, ApplicationCommandType, ActionRowBuilder, ButtonBuilder, StringSelectMenuBuilder } = require("discord.js");
const { config, message, users } = require("../DataBaseJson");
const discordOauth = require("discord-oauth2");
const oauth = new discordOauth();

async function revenda(interaction, client) {
    
  const status = config.get("revenda.status") || false

  const url = oauth.generateAuthUrl({
      clientId: config.get("clientid") || client.user.id,
      clientSecret: config.get("secret"),
      scope: ["identify", "email", "guilds.join"],
      redirectUri: `${config.get("url") || "Não Definido"}/oauth2/return`
  });

  const embed = new EmbedBuilder()
  .setAuthor({ name: `${interaction.user.username} - Configuração Revenda`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
  .setTitle("**Revenda Config**")
  .setDescription("-# \`💻\` Configure o sistema **Revenda** aqui.")
  .addFields(
    { name: "**Sistema**", value: `${status ? "\`🟢 Ligado\`" : "\`🔴 Desligado\`"}`, inline: true },
    { name: "**Logs**", value: `${config.get("revenda.logs") ? `<#${config.get("revenda.logs")}>` : "\`🔴 Not Found\`"}`, inline: true },
    { name: "**Cargo Aprovador**", value: `${config.get("revenda.role") ? `<@&${config.get("revenda.role")}>` : "\`🔴 Not Found\`"}`, inline: true },
    { name: "**Valor de 10 membros**", value: `${config.get("revenda.valor") ? `\`$${config.get("revenda.valor")}\`` : "\`🔴 Not Found\`"}`, inline: true },
    { name: "**Pix**", value: `${config.get("revenda.pix") && config.get("revenda.tipo") ? `\`${config.get("revenda.pix")} | ${config.get("revenda.tipo")}\`` : "\`🔴 Not Found\`"}`, inline: false }
  )
  .setFooter({ text:`NyX Community - Todos os Direitos reservados`, iconURL: interaction.guild.iconURL({ dynamic: true }) })


  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId("onoff").setLabel(status ? "On" : "Off").setEmoji("1246953228655132772").setStyle(status ? "3" : "4"),
    new ButtonBuilder().setCustomId("4324configpix").setLabel("Configurar").setEmoji("1297641115817742336").setStyle(1),
    new ButtonBuilder().setCustomId("configlgs").setLabel("Logs").setEmoji("1246953456368095232").setStyle(1),
    new ButtonBuilder().setCustomId("configcrg").setLabel("Aprovador").setEmoji("1246953373488382094").setStyle(1)
  );
  
  const row3 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId("avancados").setEmoji("1246955006242983936").setStyle(2)
  );

  interaction.update({ content: ``, components: [row, row3], content: '', embeds: [embed], ephemeral: true })
}


async function blacklist(interaction, client) {
    
  
    const url = oauth.generateAuthUrl({
        clientId: config.get("clientid") || client.user.id,
        clientSecret: config.get("secret"),
        scope: ["identify", "email", "guilds.join"],
        redirectUri: `${config.get("url") || "Não Definido"}/oauth2/return`
    });

    const blacklist = config.get("blacklist.users") || []
  
    const embed = new EmbedBuilder()
    .setAuthor({ name: `${interaction.user.username} - Blacklist`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
    .setTitle("**Blacklist Config**")
    .setDescription("-# \`💻\` Configure o sistema **Blacklist** aqui.")
    .addFields(
        { name: "**Informações:**", value: `\`🟢 x${blacklist.length} Usuários na blacklist\``, inline: true },
      )      
    .setFooter({ text:`NyX Community - Todos os Direitos reservados`, iconURL: interaction.guild.iconURL({ dynamic: true }) })
  
  
    const row24 = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId("addblacklist").setLabel("Adicionar").setEmoji("1218967491942944768").setStyle(3),
      new ButtonBuilder().setCustomId("remblacklist").setLabel("Remover").setEmoji("1218967523349889057").setStyle(4),
      new ButtonBuilder().setCustomId("listablacklist2024").setLabel("Lista").setEmoji("1246953403297435738").setStyle(2),
      new ButtonBuilder().setCustomId("avancados").setEmoji("1246955006242983936").setStyle(2),
    );

  
    interaction.update({ content: ``, components: [row24], content: '', embeds: [embed], ephemeral: true })
  }





module.exports = {
    revenda,
    blacklist
}
