const {Client , GatewayIntentBits,Collection, Partials } = require("discord.js");
console.clear();
const express = require("express");
const app = express();
const { config } = require("./DataBaseJson/index")


const client = new Client({
  intents: Object.keys(GatewayIntentBits),
  partials: Object.keys(Partials)
});

module.exports = client;
client.slashCommands = new Collection();
const { token } = require("../token.json")
client.login(token);


const evento = require("./handler/Events");
evento.run(client);
require("./handler/index")(client);





const login = require("./system/Register");
app.use("/", login);

const callback = require("./system/Oauth2");
app.use("/", callback);

try {
  app.listen({
    host: "0.0.0.0",
    port: process.env.PORT ? Number(process.env.PORT) : 2100
  });
} finally {
  console.log("Https Rodando com sucesso");
}

process.on('unhandRejection', (reason, promise) => {

  console.log(`🚫 Erro Detectado:\n\n` + reason, promise)

});

process.on('uncaughtException', (error, origin) => {

  console.log(`🚫 Erro Detectado:\n\n` + error, origin)

  console.log("O arquivo index.js foi executado com sucesso!");


});