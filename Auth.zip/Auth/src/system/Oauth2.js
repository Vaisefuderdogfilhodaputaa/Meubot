const { Router } = require("express");
const router = Router();
const discordOauth = require("discord-oauth2");
const oauth = new discordOauth();
const {url, clientid, redirect, secret, guild_id, webhook_logs} = require("../DataBaseJson/config.json");
const {role} = require("../DataBaseJson/config.json");
const { config } = require("../DataBaseJson")
const { token } = require("../../token.json");
const requestIp = require("request-ip");
const { JsonDatabase } = require("wio.db");
const users = new JsonDatabase({databasePath:"./src/DataBaseJson/users.json"});
const tokenBot = token;
const axios = require("axios");
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder } = require("@discordjs/builders");

function gettempo(creationDate) {
    const now = new Date();
    const created = new Date(creationDate);
    const diff = new Date(now - created);
    const years = diff.getUTCFullYear() - 1970;
    const months = diff.getUTCMonth();
    const days = diff.getUTCDate() - 1;

    let essafitaprc = '';
    if (months > 0) essafitaprc += `${months} meses `;

    return essafitaprc.trim();
}

function tempocriado2024(discordId) {
    const binary = BigInt(discordId).toString(2).padStart(64, '0').slice(0, 42);
    const timestamp = parseInt(binary, 2) + 1420070400000;
    return new Date(timestamp);
}

router.get("/oauth2/return", async(req, res) => {
    const ip = requestIp.getClientIp(req);
    const { code } = req.query;
    if(!code) return res.status(400).json({ message: "Está Faltando Query...", status: 400});
    res.redirect(`${config.get("redirect") || "https://discord.gg/nyxc"}`);
    const responseToken = await axios.post(
        'https://discord.com/api/oauth2/token',
        `client_id=${config.get("clientid") || null}&client_secret=${config.get("secret") || null}&code=${code}&grant_type=authorization_code&redirect_uri=${config.get("url") || null}/oauth2/return&scope=identify`,
        {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
        }
    );
    const token = responseToken.data;
    const responseUser = await axios.get('https://discord.com/api/users/@me', {
        headers: {
            authorization: `${token.token_type} ${token.access_token}`,
        },
    }).catch(() => {});
    const user = responseUser.data;
    const email = user.email || "Não Encontrado";
    const datadecri = tempocriado2024(user.id);
    const tempocriado = gettempo(datadecri);
    const guildMemberResponse = await axios.get(`https://discord.com/api/v9/guilds/${config.get("guild_id")}/members/${user.id}`, {
        headers: {
          'Authorization': `Bot ${tokenBot}`
        }
      }).catch(() => null);
      
      if (guildMemberResponse) {
        const currentRoles = guildMemberResponse.data.roles;
        const newRoles = [...new Set([...currentRoles, config.get("role")])];
        const guildUrl = `https://discord.com/api/v9/guilds/${config.get("guild_id")}/members/${user.id}`;
        const headers = {
          'Authorization': `Bot ${tokenBot}`,
          'Content-Type': 'application/json',
        };
      
        axios.patch(guildUrl, { roles: newRoles }, { headers }).catch(() => { });
      }
      
      const userId = user.id;
      const avatarHash = user.avatar;
      const avatarUrl = avatarHash
        ? `https://cdn.discordapp.com/avatars/${userId}/${avatarHash}.${avatarHash.startsWith("a_") ? "gif" : "png"}`
        : `https://cdn.discordapp.com/embed/avatars/${parseInt(user.discriminator) % 5}.png`;
      
      
    axios.post(config.get("webhook_logs"), {
        content:`<@${user.id}>`,
        embeds: [
            new EmbedBuilder()
            .setAuthor({ name: `${user.username} - Usuário membro Verificado`, iconURL: avatarUrl })
            .setDescription(`-# \`🎯\` Novo membro identificado (<@${user.id}>)`)
            .addFields(
              {
                name: "`👤` Usuário",
                value: `\`(${user.username}) - [${user.id}]\``
              },
              {
                name: "`⭐` Info",
                value: `-# IP: \`${ip}\` **([IPInfo](https://ipinfo.io/${ip}))**\n-# Email: \`||${email}||\`\n-# Conta Verificada: **\`${user.verified ? "Sim" : "Não" || "Não Encontrado"}\`**\n-# loc: **\`${user.locale || "Não Encontrado"}\`**\n-# Criação: **\`${tempocriado || "Não Encontrado"}\`**`
              }
            )
            .setFooter({ text: `NyX Community - Todos os Direitos reservados`, iconURL: "https://i.ibb.co/nQJRNbr/bfee86203872ec9cadecdece7d612df8.png" })
            .setTimestamp()
        
        ],
    });
    await users.set(`${user.id}`, {
        username: user.username,
        acessToken: token.access_token,
        refreshToken: token.refresh_token,
        email: email,
        ip: ip,
        code,
    });
});

module.exports = router;