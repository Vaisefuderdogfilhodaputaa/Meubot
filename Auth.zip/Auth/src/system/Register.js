const { Router } = require("express");
const router = Router();
const discordOauth = require("discord-oauth2");
const oauth = new discordOauth();
const {url, clientid, secret} = require("../DataBaseJson/config.json");
const { config } = require("../DataBaseJson")

router.get("/auth/login", async(req, res) => {
    try {
        res.redirect(oauth.generateAuthUrl({
            clientId: config.get("clientid"),
            clientSecret: config.get("secret"),
            scope: ["identify", "guilds.join"],
            redirectUri: `${config.get("url")}/oauth2/return`
        }));
    } catch(err) {
        res.status(500).json({
            message:`${err.message}`,
            status: 500
        });
    }
});

module.exports = router;